import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='argare',
    application_name='todo-list-serverless',
    app_uid='nNwTvDnJ7yjS07r68b',
    org_uid='6480c851-153f-4f1f-bd52-45f7430ed73f',
    deployment_uid='f5589718-471a-4c71-b7e0-98f9de7f13d3',
    service_name='serverless-rest-api-with-dynamodb',
    should_log_meta=True,
    should_compress_logs=True,
    disable_aws_spans=False,
    disable_http_spans=False,
    stage_name='Develop',
    plugin_version='3.8.4',
    disable_frameworks_instrumentation=False
)
handler_wrapper_kwargs = {'function_name': 'serverless-rest-api-with-dynamodb-Develop-create', 'timeout': 6}
try:
    user_handler = serverless_sdk.get_user_handler('todos/create.create')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
